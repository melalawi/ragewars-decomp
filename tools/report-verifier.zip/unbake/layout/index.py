"""The current declaration lookup and ownership of marked generated headers."""

from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path
from typing import Any

from unbake import atomic as atomic_files
from unbake import cache as retention
from unbake.config import Held, Project
from unbake.process import capture
from unbake.process import named as cause_named


def path(project: Project) -> Path:
    return project.build / "layout/index.json"


def load(project: Project) -> dict[str, Any]:
    target = path(project)
    if not target.is_file():
        return {"schema": 1, "symbols": {}, "clusters": {}, "headers": {}}
    try:
        value = _decoded(target)
        return dict(json.loads(json.dumps(value)))
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise Held(
            capture(
                error,
                cause=cause_named(
                    "layout.index", f"layout.index: {target}: {error}", owner="layout.index", stage="layout"
                ),
            )
        ) from error


def _decoded(target: Path) -> dict[str, Any]:
    def parse() -> dict[str, Any]:
        try:
            value = json.loads(target.read_bytes())
            if not isinstance(value, dict) or set(value) not in (
                {"schema", "symbols", "clusters", "headers"},
                {"schema", "symbols", "clusters", "headers", "type_headers"},
            ):
                raise ValueError("invalid index keys")
            if value["schema"] != 1 or any(not isinstance(value[k], dict) for k in ("symbols", "clusters", "headers")):
                raise ValueError("invalid schema")
            for name, digest in value["headers"].items():
                safe(name)
                if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                    raise ValueError("invalid header sha256")
            for name in (*value["symbols"].values(), *value["clusters"].values()):
                safe(name)
                if name not in value["headers"]:
                    raise ValueError("unlisted declaration home")
            if not isinstance(value.get("type_headers", {}), dict):
                raise ValueError("invalid type catalogue")
            for homes in value.get("type_headers", {}).values():
                if not isinstance(homes, list):
                    raise ValueError("invalid type homes")
                for home in homes:
                    safe(home)
                    if home not in value["headers"]:
                        raise ValueError("unlisted type home")
            return value
        except (OSError, ValueError, KeyError, TypeError) as error:
            raise Held(
                capture(
                    error,
                    cause=cause_named(
                        "layout.index", f"layout.index: {target}: {error}", owner="layout.index", stage="layout"
                    ),
                )
            ) from error

    from unbake import inputs

    return retention.memo(
        "layout.index",
        (str(target), inputs.digest(target, algorithm="sha256", reuse=retention.configured())),
        parse,
        size=retention.memory_size,
        copy_out=retention.clone,
    )


def safe(name: str) -> None:
    if not isinstance(name, str):
        raise ValueError(f"unsafe header path {name!r}")
    p = Path(name)
    if p.is_absolute() or ".." in p.parts or p.suffix != ".h":
        raise ValueError(f"unsafe header path {name!r}")


def headers(project: Project) -> frozenset[Path]:
    """The generated headers the index lists that exist: a header missing from a fresh or partial tree is not an
    input; the headers step regenerates it from the type solution."""
    return frozenset(path for path in listed(project) if path.is_file())


def marked(path: Path, root: Path) -> bool:
    """Recognize the generator's guard, never a filename pattern alone."""
    if not path.is_relative_to(root) or not path.is_file():
        return False
    name = path.relative_to(root).as_posix()
    guard = "UNBAKE_" + re.sub(r"[^A-Za-z0-9]", "_", name).upper()
    text = path.read_text()
    # Generated layout homes are beneath a segment/common directory. Root
    # SDK/scalar headers such as types.h can share the UNBAKE guard prefix;
    # they remain authored unless they carry an explicit declaration marker.
    if len(Path(name).parts) < 2 and not any(
        marker in text for marker in ("/* unbake published declaration:", "/* unbake declaration evidence:")
    ):
        return False
    return bool(re.match(r"\s*#\s*ifndef\s+" + guard + r"\s*\n\s*#\s*define\s+" + guard + r"\b", text))


def owned(project: Project) -> frozenset[Path]:
    """Manifest homes plus marked orphans, including files absent from the index.

    Ownership survives a renamed content-addressed header or a discarded index.
    Authored headers with similar names remain outside this set.
    """
    found = set(headers(project))
    if project.include:
        root = project.include[0]
        for path in root.rglob("*.h"):
            if marked(path, root):
                if not path.resolve().is_relative_to(root.resolve()):
                    raise Held(
                        cause_named(
                            "layout.index",
                            "layout.index: header symlink escapes include root",
                            owner="layout.index",
                            stage="layout",
                        )
                    )
                found.add(path)
    return frozenset(found)


def listed(project: Project) -> frozenset[Path]:
    if not project.include:
        return frozenset()
    target = path(project)
    if not target.is_file():
        # A warm clone can omit the disposable index while retaining its
        # installed headers. Recover only guarded, map-owned generation homes;
        # treating them as authored would overwrite their consumed declarations.
        ownership = project.root / "layout.toml"
        if not ownership.is_file():
            return frozenset()
        stat = ownership.stat()
        return _unindexed_headers(project.include[0], ownership, (stat.st_ino, stat.st_mtime_ns, stat.st_size))
    stat = target.stat()
    names = tuple(_decoded(target)["headers"])
    return _headers(project.include[0], names, (stat.st_ino, stat.st_mtime_ns, stat.st_size))


def _unindexed_headers(root: Path, ownership: Path, stamp: tuple[int, int, int]) -> frozenset[Path]:
    try:
        groups = tomllib.loads(ownership.read_text()).get("group", [])
        # common/types.h and <segment>/types.h are the pre-co-usage homes, found so they are removed.
        names = {"common/types.h", "common/data.h", "common/unused.h"}
        names.update(path.relative_to(root).as_posix() for path in (root / "common").glob("types_*.h"))
        for group in groups:
            segment, name = group["segment"], group["name"]
            names.update((f"{segment}/{name}.h", f"{segment}/types.h", f"{segment}/data.h"))
            # Inferred modules rename tool-named groups; their old headers are still generated output.
            names.update(
                path.relative_to(root).as_posix()
                for path in (root / segment).glob("code_*.h")
                if re.fullmatch(r"code_[0-9A-F]{8}\.h", path.name)
            )
        found = []
        for name in sorted(names):
            safe(name)
            path = root / name
            if not path.is_file():
                continue
            if not path.resolve().is_relative_to(root.resolve()):
                raise ValueError("header symlink escapes include root")
            guard = "UNBAKE_" + re.sub(r"[^A-Za-z0-9]", "_", name).upper()
            if re.match(r"\s*#\s*ifndef\s+" + guard + r"\s*\n\s*#\s*define\s+" + guard + r"\b", path.read_text()):
                found.append(path)
        return frozenset(found)
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise Held(
            capture(
                error,
                cause=cause_named(
                    "layout.index",
                    f"layout.index: unindexed installed headers: {error}",
                    owner="layout.index",
                    stage="layout",
                ),
            )
        ) from error


def _headers(root: Path, names: tuple[str, ...], stamp: tuple[int, int, int]) -> frozenset[Path]:
    result = frozenset(root / name for name in names)
    if any(not p.resolve().is_relative_to(root.resolve()) for p in result):
        raise Held(
            cause_named(
                "layout.index",
                "layout.index: header symlink escapes include root",
                owner="layout.index",
                stage="layout",
            )
        )
    return result


def encoded(value: dict[str, Any]) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def overlay(value: dict[str, Any], changes: dict[str, str]) -> dict[str, Any]:
    """Catalogue explicit current header bytes, including typedef definition homes.

    A fold can change a module header without regenerating the whole index.
    Replace that home's old exports and type entries before rewriting imports.
    """
    import hashlib

    from unbake.cdecl import declarations
    from unbake.typemap.header_names import alias_types

    result = {**value, "headers": dict(value["headers"])}
    result["symbols"] = {symbol: home for symbol, home in value["symbols"].items() if home not in changes}
    types = {symbol: set(homes) - changes.keys() for symbol, homes in value.get("type_headers", {}).items()}
    aliases = {}
    for name, text in sorted(changes.items()):
        safe(name)
        result["headers"][name] = hashlib.sha256(text.encode()).hexdigest()
        row = declarations(text)
        for symbol in row.typedefs | row.declared | row.exports:
            result["symbols"][symbol] = name
        for symbol in row.typedefs | row.tags | row.declared | row.exports:
            types.setdefault(symbol, set()).add(name)
        aliases.update(alias_types(text))
    # A typedef may only forward its tag; consumers that access fields need
    # both the typedef provider and the complete definition provider.
    for alias, target in aliases.items():
        pending = [target]
        seen = {alias}
        while pending:
            target = pending.pop()
            match = re.fullmatch(r"(?:struct|union|enum)\s+(\w+)", target)
            name = match[1] if match else target
            if name in seen and not match:
                continue
            types.setdefault(alias, set()).update(types.get(name, set()))
            if name not in seen:
                seen.add(name)
                if name in aliases:
                    pending.append(aliases[name])
    result["type_headers"] = {symbol: sorted(homes) for symbol, homes in types.items() if homes}
    return result


def update(project: Project, changes: dict[Path, str]) -> None:
    """Register explicit fold outputs; never rediscover headers by scanning."""
    from unbake.typemap import storage

    value = overlay(load(project), {p.relative_to(project.include[0]).as_posix(): t for p, t in changes.items()})
    atomic_files.write(storage.output(path(project)), encoded(value))
