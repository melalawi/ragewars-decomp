"""Preview and transactionally apply layout edits."""

from __future__ import annotations

import difflib
from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING

from unbake import atomic as atomic_files
from unbake.config import Held
from unbake.layout import split
from unbake.process import named as cause_named

if TYPE_CHECKING:
    from unbake.build import Outcome
    from unbake.config import Host, Project


def coalesce(edits: Iterable[split.Edit]) -> list[split.Edit]:
    result: dict[Path, split.Edit] = {}
    for edit in edits:
        if not isinstance(edit, split.Edit):
            raise Held(cause_named("edits", "edits: required Edit records", owner="layout.split_apply", stage="split"))
        path = Path(edit.path)
        if not edit.versions:
            raise Held(cause_named(f"{path}", f"{path}: affected versions", owner="layout.split_apply", stage="split"))
        if path in result:
            previous = result[path]
            if edit.before != previous.after:
                raise Held(
                    cause_named(f"{path}", f"{path}: conflicting edits", owner="layout.split_apply", stage="split")
                )
            result[path] = split.Edit(
                path, previous.before, edit.after, tuple(dict.fromkeys((*previous.versions, *edit.versions)))
            )
        else:
            result[path] = edit
    return [edit for edit in result.values() if edit.before != edit.after]


def diff(edits: Iterable[split.Edit]) -> str:
    return "".join(
        "".join(
            difflib.unified_diff(
                edit.before.splitlines(keepends=True),
                edit.after.splitlines(keepends=True),
                fromfile=str(edit.path),
                tofile=str(edit.path),
            )
        )
        for edit in coalesce(edits)
    )


def write(path: Path, text: str) -> None:
    atomic_files.text(Path(path), text, encoding="utf-8")


def _validated(project: Project, edits: Iterable[split.Edit]) -> tuple[list[split.Edit], list[str]]:
    edits = coalesce(edits)
    if not edits:
        return [], []
    allowed = {
        Path(path).resolve(): v
        for v in project.versions
        for path in (project.version(v).split, project.version(v).symbols)
    }
    affected: set[str] = set()
    for edit in edits:
        path = Path(edit.path)
        shared = path.resolve() == (project.root / "layout.toml").resolve()
        source = path.resolve().is_relative_to(Path(project.src).resolve())
        if path.resolve() not in allowed and not shared:
            if not hasattr(project, "include"):
                raise Held(
                    cause_named(
                        "project.include", "project.include: missing value", owner="layout.split_apply", stage="split"
                    )
                )
            shared = any(path.resolve().is_relative_to(Path(directory).resolve()) for directory in project.include)
        if (path.resolve() not in allowed and not shared and not source) or not path.resolve().is_relative_to(
            project.root.resolve()
        ):
            raise Held(
                cause_named(
                    f"{path}",
                    f"{path}: edit must target layout.toml or a configured split, symbols, src or include file",
                    owner="layout.split_apply",
                    stage="split",
                )
            )
        if (split.read(path) if path.exists() else "") != edit.before:
            raise Held(
                cause_named(f"{path}", f"{path}: changed since dry run", owner="layout.split_apply", stage="split")
            )
        for v in edit.versions:
            project.version(v)
            affected.add(v)
        if shared:
            affected.update(project.versions)
        # Shared configured files affect every VERSION that reads them.
        for v in project.versions:
            version = project.version(v)
            if path.resolve() in (Path(version.split).resolve(), Path(version.symbols).resolve()):
                affected.add(v)
    return edits, [v for v in project.versions if v in affected]


def _write_staging(project: Project, edits: Iterable[split.Edit]) -> None:
    """Write validated edits in a private tree before its full publication proof."""
    edits, _ = _validated(project, edits)
    written: list[tuple[split.Edit, bool]] = []
    try:
        for edit in edits:
            existed = Path(edit.path).exists()
            write(edit.path, edit.after)
            written.append((edit, existed))
    except BaseException:
        for edit, existed in reversed(written):
            if existed:
                write(edit.path, edit.before)
            else:
                Path(edit.path).unlink(missing_ok=True)
        raise


def apply(project: Project, policy: Host, edits: Iterable[split.Edit]) -> Outcome | None:
    """Write the edits, regenerate the build files and prove every version with make check; revert on failure."""
    from unbake import build, buildfiles, steps

    edits, _versions = _validated(project, edits)
    if not edits:
        return None
    prepared = steps.prepare(
        project,
        policy,
        steps.PrepareRequest(
            "boundary",
            (),
            proposed={edit.path: edit.after for edit in edits if edit.path.suffix == ".c"},
            project_scope=True,
        ),
    )
    prepared.assert_current(project)
    written: list[tuple[split.Edit, bool]] = []
    before = {path: path.read_bytes() for path in buildfiles.generate(project, policy) if path.is_file()}

    def revert() -> None:
        for edit, existed in reversed(written):
            if existed:
                write(edit.path, edit.before)
            else:
                Path(edit.path).unlink(missing_ok=True)
        for path, content in before.items():
            atomic_files.write(path, content)

    try:
        prepared.assert_current(project)
        _validated(project, edits)
        for edit in edits:
            existed = Path(edit.path).exists()
            write(edit.path, edit.after)
            written.append((edit, existed))
        buildfiles.write(project, policy)
        outcome = build.check(project, policy)
    except BaseException:
        revert()
        raise
    if not outcome.ok:
        revert()
    return outcome
