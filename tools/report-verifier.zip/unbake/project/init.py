"""Create a repository shell without ROM, policy, compiler or build work."""

import json
import shutil
import subprocess
from pathlib import Path
from uuid import uuid4

from unbake import atomic as atomic_files
from unbake.config import SCHEMA_VERSION, Held
from unbake.process import temporary_environment
from unbake.project import hygiene


def readme_text(target: Path) -> str:
    """A minimal owner document with a tool-owned Progress body."""
    template = Path(__file__).parents[1] / "templates" / "README.ready.md"
    return template.read_text().replace("@TITLE@", target.name)


def run(target: Path, *, layout_cap: int) -> list[str]:
    from unbake.layout.map import positive

    positive(layout_cap, "project.layout_cap")
    target = Path(target).expanduser().absolute()
    if target.is_symlink() or any(parent.is_symlink() for parent in target.parents):
        raise Held("init", f"init.target: {target}: symlink")
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise Held("init", f"init.target: {target}: expected empty directory")
    if target.name in ("", ".", "..") or any(ord(character) < 32 for character in target.name):
        raise Held("init", f"init.target: {target}: invalid filesystem name")
    git = shutil.which("git")
    if git is None:
        raise Held("init", "git: missing executable")
    template = Path(__file__).parents[1] / "templates" / "CONTRIBUTING.pending.md"
    try:
        contributing = template.read_text()
    except OSError as error:
        raise Held("init", f"init.docs: {template}: {error}") from error
    existed = target.exists()
    target.mkdir(parents=True, exist_ok=True)
    try:
        result = subprocess.run(
            [git, "init", "-b", "main"],
            cwd=target,
            env=temporary_environment(target / "build"),
            capture_output=True,
            text=True,
        )
        if result.returncode:
            raise Held("init", f"git: {result.stderr.strip()}")
        quote = json.dumps
        atomic_files.text(
            target / "config.toml",
            f"schema = {SCHEMA_VERSION}\n\n[project]\n"
            f'id = {quote(str(uuid4()))}\nstate = "awaiting-roms"\nlayout_cap = {layout_cap}\n',
        )
        from unbake.layout.map import Map, encoded

        atomic_files.write(target / "layout.toml", encoded(Map(layout_cap, ())))
        atomic_files.text(target / ".gitignore", hygiene.base_ignore_text(target))
        (target / "roms").mkdir()
        atomic_files.text(target / "README.md", readme_text(target))
        atomic_files.text(target / "CONTRIBUTING.md", contributing)
    except BaseException:
        shutil.rmtree(target)
        if existed:
            target.mkdir()
        raise
    return [f"{target}: repository created", f"ROM folder: {target / 'roms'}"]


def write_host_example(path: Path) -> bool:
    """Write the commented host config example at PATH unless a file is already there."""
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_files.text(path, (Path(__file__).parents[1] / "templates" / "unbake.toml").read_text())
    return True
