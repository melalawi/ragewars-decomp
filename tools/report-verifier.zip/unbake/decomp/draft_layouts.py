"""Resolve decompiler unknowns before they cross the shared-header boundary."""

import re

from unbake.cdecl import SOURCE_TOKEN, LayoutParser
from unbake.config import Held
from unbake.decomp import opaque_pointers
from unbake.decomp.draft_macros import calls
from unbake.layout.structs_types import SCALARS
from unbake.process import named as cause_named

_ACCESS = re.compile(r"^\s*[ls](b|bu|h|hu|w|d)\s", re.M)
_WIDTHS = {"b": 1, "bu": 1, "h": 2, "hu": 2, "w": 4, "d": 8}


def access_widths(assembly: str) -> frozenset[int]:
    """The widths of the integer loads and stores in the target ASSEMBLY."""
    return frozenset(_WIDTHS[match[1]] for match in _ACCESS.finditer(assembly))


def _field_of(source: str, name: str) -> str | None:
    """The offset of the first M2C_FIELD whose type argument names the unknown NAME."""
    found: list[str] = []

    def note(args: list[str]) -> str:
        if len(args) == 3 and re.search(r"\b" + name + r"\b", args[1]):
            found.append(args[2])
        return ""

    calls(source, "M2C_FIELD", note)
    return found[0] if found else None


def normalize(source: str, context: str, accessed: frozenset[int] = frozenset()) -> str:
    """Replace only unknowns whose target ABI width is established by a typedef, or by the one width every
    integer access of the target (ACCESSED) uses.

    Scalar spelling also makes pointers and arrays self-contained in a shared
    header, independently of whether its consumers include m2c's prelude.
    Unknown type names without layout evidence are refused before any write.
    """
    source = opaque_pointers.normalize(source, context)
    parser = LayoutParser(context + "\n" + source)
    # Collect typedefs without evaluating aggregates: a member can itself be
    # the unknown that this pass is about to resolve.
    while parser.peek():
        if parser.peek() == "typedef":
            parser.take()
            parser.declaration(typedef=True)
        else:
            parser.skip_external()
    replacements = []
    for token in SOURCE_TOKEN.finditer(source):
        name = token[0]
        if not re.fullmatch(r"M2C_UNK\d*", name):
            continue
        if name not in parser.types:
            field = _field_of(source, name)
            if field is not None:
                raise Held(
                    cause_named(
                        f"{name}",
                        f"{name}: the field at {field} is dereferenced but its pointee has no measured layout",
                        owner="decomp.draft_layouts",
                        stage="m2c",
                    )
                )
            if len(accessed) != 1:
                raise Held(
                    cause_named(
                        f"{name}",
                        f"{name}: unknown type has no declared target layout",
                        owner="decomp.draft_layouts",
                        stage="m2c",
                    )
                )
            replacements.append((token.start(), token.end(), f"s{next(iter(accessed)) * 8}"))
            continue
        spelling = parser.type_name(name, ())
        if spelling not in SCALARS or spelling in ("float", "double", "f32", "f64"):
            raise Held(
                cause_named(
                    f"{name}",
                    f"{name}: unknown type has unsupported target layout {spelling}",
                    owner="decomp.draft_layouts",
                    stage="m2c",
                )
            )
        width = SCALARS[spelling][0]
        replacements.append((token.start(), token.end(), f"s{width * 8}"))
    for start, end, value in reversed(replacements):
        source = source[:start] + value + source[end:]
    return source
